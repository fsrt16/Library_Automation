import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class Student {

    String []g=new String[3];
    String d;
    /* Class containing left and right child of current node and key value*/
    class Node {
        String k1;
        int key;
        String First_name;
        String Last_name;
        String Branch;
        String book1;
        String book1_return;
        String book1_take;
        String book2;
        String book2_return;
        String book2_take;
        String number ;


        Node left, right;

        public Node(int item,String f,String l,String b,String m , String s , String s1,String n , String a , String a1,String k,String n1) {
            this.k1=k;
            this.key=(item);
            this.First_name=f;
            this.Last_name=l;
            this.Branch=b;
            this.book1 = m ;
            this.book1_return=s1;
            this.book1_take=s;
            this.book2=n;
            this.book2_return=a1;
            this.book2_take=a;
            this.number=n1;
            left = right = null;
        }

    }

    // Root of BST
    Node root;

    Book_Details b;
    // Constructor
    Student() {
        root = null;
       
        initiate();
     

    }


    
    // This method mainly calls insertRec()
    void insert(String key , String f ,String l , String b,String m,String s,String s1, String n,String a, String a1,String n1) {

        int key1 = decode(key);
        root = insertRec(root, key1 , f , l ,  b,m,s,s1,n,a,a1,key,n1);
    }

    /* A recursive function to insert a new key in BST */
    Node insertRec(Node root, int key, String f ,String l , String b,String m,String s,String s1,String n,String a, String a1,String key1,String n1) {

        /* If the tree is empty, return a new node */
        if (root == null) {
            root = new Node(key, f ,l , b,m,s,s1,n,a,a1,key1,n1);

            return root;
        }

        /* Otherwise, recur down the tree */
        if (key < root.key)
            root.left = insertRec(root.left, key,f,l,b,"0","--/--/---","--/--/---","0","--/--/---","--/--/---",key1,n1);
        else if (key > root.key)
            root.right = insertRec(root.right, key,f,l,b,"0","--/--/---","--/--/---","0","--/--/---","--/--/---",key1,n1);

        /* return the (unchanged) node pointer */
        return root;
    }

    // This method mainly calls InorderRec()
    void inorder()  {
        inorderRec(root);
    }
  void Print_desired_node(int p){

       System.out.println("CALLED");
        printDN(root,p);
        
        
        //System.out.println("call");
    }
   String[] Print_desired_node2(int p){

       
        printDN(root,p);
        return g;
        //System.out.println("call");
    }
    void printDN(Node root,int p){
        if (root != null) {

            printDN(root.left,p);
            if(root.key==p) {
              
                 //System.out.println("calfal");
                 
               String g0=root.k1 + "   " + root.First_name + "   " + root.Last_name + "   " + root.Branch;
               String g1=root.book1 + "   " + root.book1_take + "   " + root.book1_return +"   ";
               
             String g3=root.book2 + "   " + root.book2_take + "   " + root.book2_return+"   ";
              
                  //System.out.println("CALLED");
                g[0]=g0;
                g[1]=g1;
                g[2]=g3;
                
                System.out.println(g[0] + g[1]+g[2]);
                  System.out.println("CALLED");
             
                 
            }
            printDN(root.right,p);
        }
        
    }
    void Print_desired_node1(int p){

        printDN1(root,p);
        
    }
    void printDN1(Node root,int p){
        if (root != null) {

            printDN1(root.left,p);
            if(root.key==p) {
               
                
                g[0]=root.k1 + "   " + root.First_name + "   " + root.Last_name + "   " + root.Branch;
                g[1]=root.book1 + "   " + root.book1_take + "   " + root.book1_return +"   ";
                g[2]=b.searc_IS(root.book1);
                g[3]=root.book2 + "   " + root.book2_take + "   " + root.book2_return+"   ";
                g[4]=b.searc_IS(root.book2);
                
            }
            printDN1(root.right,p);
        }
    }
    public int CHECK_FOR_REGISTRATION_NUMBER(String reg_no)
    {
        Node a = root;

        while(a!=null)
        {
            if(a.key == decode(reg_no))
                return 0;
            else if(a.key < decode(reg_no))
            {

                a=a.right;
            }
            else
            {

                a=a.left;
            }

        }
        return 1;
    }

    // A utility function to do inorder traversal of BST
    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.k1+"  " + root.First_name + "  "+root.Last_name+"  "+root.Branch);
            System.out.println(root.book1 +"   "+root.book1_take+"   "+root.book1_return);
            System.out.println(root.book2 +"   "+root.book2_take+"   "+root.book2_return);
            inorderRec(root.right);
        }
    }
    public int decode(String a)
    {
        a=a.toUpperCase();
        char a1[]=a.toCharArray();
        int  s=0;
        for(int i=0;i<a.length();i++)
        {
            s=s+i*(int)a1[i];
        }
        return s;
    }
    public Node findNodeInBST(Node node, int value) {
        if(null == node) {
            return null;
        }
        //Condition 1. we found the value
        if(node.key == value) {
            return node;
        }
        //Condition 2.
        //Value is less than node value. so go left sub tree
        else if(value < node.key)
            return findNodeInBST(node.left,value);
            //Condition 3.
            //Value is greater than node value. so go right sub tree
        else
            return findNodeInBST(node.right,value);
    }

    public String[] entry(int p,String s1,String s2)
    {
       // System.out.println("calledtry");
        ent(root,p,s1,s2);
      
        return g;
    }
    public void ent(Node root, int p, String s1,String s2)
    {
        if(root!=null) {
            ent(root.left,p,s1,s2);
           
            if(root.key == p)
            {
               


                            if(root.book1.equals("0"))
                            {
                                //System.out.println("calledtry");
                                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                                Date date = new Date();
                                root.book1=s1;
                                root.book1_take=(dateFormat.format(date));
                                int x=(decode(s2));
                                String ddt = (dateFormat.format(date));
                                char []ddt1=ddt.toCharArray();
                                String ch="";
                                for(int i=0;i<ddt.length();i++)
                                {
                                    if(i>=8 && i<=9 )
                                    {
                                        ch=ch+ddt1[i];
                                    }
                                }
                                int ch1 = Integer.valueOf(ch);
                                if(ch1<=17)
                                {
                                    ch1 =ch1+14;}
                                else
                                {
                                    int  xyui=31-ch1;
                                    ch1=14-xyui;
                                }
                                   String cty;
                               if(ch1/10==0) {
                                    System.out.println("CALLED");
                                    cty = "0"+ch1;
                                }
                                else {
                                    cty = String.valueOf(ch1);
                                }
                                char []ddt23=cty.toCharArray();
                                int io=0;
                                  System.out.print(ch1);
                                for(int i=0;i<ddt.length();i++)
                                {
                                    if(i>=8 && i<=9 )
                                    {
                                        ddt1[i]=ddt23[io];
                                        io=io+1;
                                    }
                                }
                              
                                String s0 =String.valueOf(ddt1);
                                root.book1_return=s0;
                                                              updtbst(root.key,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return);
                               Print_desired_node(x);
                               update1(root.number);
                                insert12(root.k1,root.First_name,root.Last_name,root.Branch,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return,root.number);


                            }
                            else if (root.book2.equals("0"))
                            {
                                
                               // System.out.println("calledtbjkbjkry");
                                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                                Date date = new Date();
                                root.book2=s1;
                                root.book2_take=(dateFormat.format(date));
                                int x=(decode(s2));
                                String ddt = (dateFormat.format(date));
                                char []ddt1=ddt.toCharArray();
                                String ch="";
                                for(int i=0;i<ddt.length();i++)
                                {
                                    if(i>=8 && i<=9 )
                                    {
                                        ch=ch+ddt1[i];
                                    }
                                }
                                int ch1 = Integer.valueOf(ch);
                                if(ch1<=17)
                                {
                                    ch1 =ch1+14;}
                                else
                                {
                                    int  xyui=31-ch1;
                                    ch1=14-xyui;
                                }
                                String cty;
                               if(ch1/10==0) {
                                    System.out.println("CALLED");
                                    cty = "0"+ch1;
                                }
                                else {
                                    cty = String.valueOf(ch1);
                                }
                                char []ddt23=cty.toCharArray();
                                int io=0;
                                for(int i=0;i<ddt.length();i++)
                                {
                                    if(i>=8 && i<=9 )
                                    {
                                        ddt1[i]=ddt23[io];
                                        io=io+1;
                                    }
                                }
                                String s0 =String.valueOf(ddt1);
                                root.book2_return=s0;
                                updtbst(root.key,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return);
                                Print_desired_node(x);
                                update1(root.number);
                                 insert12(root.k1,root.First_name,root.Last_name,root.Branch,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return,root.number);
                                

                            }


                          
                        
            }
                        
            ent(root.right,p,s1,s2);
        }
    }
    
    public String submit(String s)
    {
        sub(root,s);
        return d;
    }
    public void sub(Node root , String s) {
        if (root != null) {

            sub(root.left, s);
            if (root.book1.equals(s)) {
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                Date date = new Date();
                String dt = dateFormat.format(date);

                char[] a1 = dt.toCharArray();
                String b1 = "";
                String c1 = "";
                String d1 = "";
                for (int i = 0; i < dt.length(); i++) {
                    if (i == 0) {
                        while (i != 4) {

                            b1 = b1 + a1[i];
                            i = i + 1;
                        }
                    }
                    if (i == 5) {
                        while (i != 7) {

                            c1 = c1 + a1[i];
                            i = i + 1;
                        }
                    }
                    if (i == 8) {
                        while (i != 10) {

                            d1 = d1 + a1[i];
                            i = i + 1;
                        }
                    }


                }
                int bin1=Integer.parseInt(b1);
                int cin1=Integer.parseInt(c1);
                int din1=Integer.parseInt(d1);
                //System.out.println(bin1 +" " +cin1+" "+din1);



                char[] a = root.book1_return.toCharArray();
                String b = "";
                String c = "";
                String d = "";
                for (int i = 0; i < root.book1_return.length(); i++) {
                    if (i == 0) {
                        while (i != 4) {

                            b = b + a[i];
                            i = i + 1;
                        }
                    }
                    if (i == 5) {
                        while (i != 7) {

                            c = c + a[i];
                            i = i + 1;
                        }
                    }
                    if (i == 8) {
                        while (i != 10) {

                            d = d + a[i];
                            i = i + 1;
                        }
                    }


                }
                int bin=Integer.parseInt(b);
                int cin=Integer.parseInt(c);
                int din=Integer.parseInt(d);
                //System.out.println(bin +" " +cin+" "+din);
                int days =(bin1-bin)*365 ;
                if((cin1-cin )>0)
                    days =days + (cin1-cin )*31;
                if((din1-din )>0)
                    days =days + (din1-din );
                //System.out.println("FINE " + " --> " +3*days);
                //System.out.println("BOOK SUBMITTED");
                //Print_desired_node(root.key);
                root.book1=root.book2;
                root.book1_take=root.book2_take;
                root.book1_return=root.book2_return;
                //System.out.println(root.book1_return+"  "+root.book1_take+"  "+root.book1);
                root.book2="0";
                root.book2_take=" -- ";
                root.book2_return=" -- ";
                //System.out.println(root.book2_return+"  "+root.book2_take+"  "+root.book2);
                
                update1(root.number);
                                 insert12(root.k1,root.First_name,root.Last_name,root.Branch,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return,root.number);
                                d= String.valueOf(3*days);
            }
            if(root.book2.equals(s))
            {
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                Date date = new Date();
                String dt = dateFormat.format(date);

                char[] a1 = dt.toCharArray();
                String b1 = "";
                String c1 = "";
                String d1 = "";
                for (int i = 0; i < dt.length(); i++) {
                    if (i == 0) {
                        while (i != 4) {

                            b1 = b1 + a1[i];
                            i = i + 1;
                        }
                    }
                    if (i == 5) {
                        while (i != 7) {

                            c1 = c1 + a1[i];
                            i = i + 1;
                        }
                    }
                    if (i == 8) {
                        while (i != 10) {

                            d1 = d1 + a1[i];
                            i = i + 1;
                        }
                    }


                }
                int bin1=Integer.parseInt(b1);
                int cin1=Integer.parseInt(c1);
                int din1=Integer.parseInt(d1);
                //System.out.println(bin1 +" " +cin1+" "+din1);



                char[] a = root.book1_return.toCharArray();
                String b = "";
                String c = "";
                String d = "";
                for (int i = 0; i < root.book1_return.length(); i++) {
                    if (i == 0) {
                        while (i != 4) {

                            b = b + a[i];
                            i = i + 1;
                        }
                    }
                    if (i == 5) {
                        while (i != 7) {

                            c = c + a[i];
                            i = i + 1;
                        }
                    }
                    if (i == 8) {
                        while (i != 10) {

                            d = d + a[i];
                            i = i + 1;
                        }
                    }


                }
                int bin=Integer.parseInt(b);
                int cin=Integer.parseInt(c);
                int din=Integer.parseInt(d);
                //System.out.println(bin +" " +cin+" "+din);
                int days =(bin1-bin)*365 ;
                if((cin1-cin )>0)
                    days =days + (cin1-cin )*31;
                if((din1-din )>0)
                    days =days + (din1-din );
                System.out.println("FINE " + " --> " +3*days);
                System.out.println("BOOK SUBMITTED");
                //Print_desired_node(root.key);
                //System.out.println(root.book1_return+"  "+root.book1_take+"  "+root.book1);
                root.book2="0";
                root.book2_take=" -- ";
                root.book2_return=" -- ";
                //System.out.println(root.book2_return+"  "+root.book2_take+"  "+root.book2);
                update1(root.number);
                insert12(root.k1,root.First_name,root.Last_name,root.Branch,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return,root.number);
                                
                d= String.valueOf(3*days);
            }
            sub(root.right, s);
        }
    }

public void rei(String s,String s1)
{
 r1node(root,s,s1);
 
}
public void r1node(Node root,String s, String s1)
{
     if (root != null) {
            r1node(root.left,s,s1);
            if(root.book1.equalsIgnoreCase(s1))
            {
                   DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                            Date date = new Date();
                            root.book1 = s1;
                            root.book1_take = (dateFormat.format(date));
                            int x = (decode(s));
                            String ddt = (dateFormat.format(date));
                            char[] ddt1 = ddt.toCharArray();
                            String ch = "";
                            for (int i = 0; i < ddt.length(); i++) {
                                if (i >= 8 && i <= 9) {
                                    ch = ch + ddt1[i];
                                }
                            }
                            int ch1 = Integer.valueOf(ch);
                            if (ch1 <= 17) {
                                ch1 = ch1 + 14;
                            } else {
                                int xyui = 31 - ch1;
                                ch1 = 14 - xyui;
                            }
                            String cty = String.valueOf(ch1);
                            char[] ddt23 = cty.toCharArray();
                            int io = 0;
                            for (int i = 0; i < ddt.length(); i++) {
                                if (i >= 8 && i <= 9) {
                                    ddt1[i] = ddt23[io];
                                    io = io + 1;
                                }
                            }
                            String s0 = String.valueOf(ddt1);
                            root.book1_return = s0;
            update1(root.number);
                                 insert12(root.k1,root.First_name,root.Last_name,root.Branch,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return,root.number);
                                                
            
            }
            else if(root.book2.equalsIgnoreCase(s1)) {
                            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                            Date date = new Date();
                            root.book2 = s1;
                            root.book2_take = (dateFormat.format(date));
                            int x = (decode(s));
                            String ddt = (dateFormat.format(date));
                            char[] ddt1 = ddt.toCharArray();
                            String ch = "";
                            for (int i = 0; i < ddt.length(); i++) {
                                if (i >= 8 && i <= 9) {
                                    ch = ch + ddt1[i];
                                }
                            }
                            int ch1 = Integer.valueOf(ch);
                            if (ch1 <= 17) {
                                ch1 = ch1 + 14;
                            } else {
                                int xyui = 31 - ch1;
                                ch1 = 14 - xyui;
                            }
                            String cty = String.valueOf(ch1);
                            char[] ddt23 = cty.toCharArray();
                            int io = 0;
                            for (int i = 0; i < ddt.length(); i++) {
                                if (i >= 8 && i <= 9) {
                                    ddt1[i] = ddt23[io];
                                    io = io + 1;
                                }
                            }
                            String s0 = String.valueOf(ddt1);
                            root.book2_return = s0;
            update1(root.number);
                                 insert12(root.k1,root.First_name,root.Last_name,root.Branch,root.book1,root.book1_take,root.book1_return,root.book2,root.book2_take,root.book2_return,root.number);
                                                
            
            }
           r1node(root.right,s,s1);
        }
}

public void updtbst(int p,String b1,String b1t,String b1r,String b2,String b2t,String b2r)
{
    updbst(root,p,b1,b1t,b1r,b2,b2t,b2r);
}
public void updbst(Node root,int p,String b1,String b1t,String b1r,String b2,String b2t,String b2r)
{
    if(root!=null)
    {
        updbst(root.left,p,b1,b1t,b1r,b2,b2t,b2r);
        if(root.key==p)
        {
            root.book1=b1;
            root.book1_take=b1t;
            root.book1_return=b1r;
             root.book2=b2;
            root.book2_take=b2t;
            root.book2_return=b2r;
        }
        
        updbst(root.right,p,b1,b1t,b1r,b2,b2t,b2r);
        
    }
}



    public  void initiate()
    {
        enter();
    }
    public   void jlt(){

        insert1("17bce7100","TATHAGAT","BANERJEE","CSE","ISIB5224AP","2018/09/07","2018/09/21","0","0","0");
        insert1("17bec7039","ASHITA","SATPATHY","ECE","0","--/--/----","--/--/---","0","--/--/---","--/--/---");
        insert1("17bes7002","ANkur","RUNGTA","ECE","0","--/--/----","--/--/---","0","--/--/---","--/--/---");
        insert1("17bes7042","ashwin","vinod","ECE","0","--/--/----","--/--/---","0","--/--/---","--/--/---");
    }
    public String REGISTRATION (String a1 ,String b1,String c1,String d1)
    {
                   
                    
        
        String r= new String();
                Node n = findNodeInBST(root, decode(a1));
                if (n == null) {
                    {
                        String yui=" ";
                        try{
                           Connection  con = DriverManager.
                    getConnection("jdbc:derby://localhost:1527/Student"
                        ,"tathagat","tathagat");
                           Statement st;
           st=con.createStatement();
                        ResultSet rs = st.executeQuery("SELECT * FROM STD");
                        int i=0;
                        while(rs.next())
                        {
                           
                            String n1=rs.getString("NUMER");
                            int k=Integer.parseInt(n1);
                            if(k>i)
                                i=k;
                        }
                        yui=String.valueOf(i+1);
                        System.out.println(yui);
                        
                        }catch(SQLException e) {
         System.out.println("SQL exception occured" + e);
      }
                        insert12(a1, b1, c1, d1, "0", "--/--/---", "--/--/---", "0", "--/--/---", "--/--/---",yui);
                        insert(a1, b1, c1, d1, "0", "--/--/---", "--/--/---", "0", "--/--/---", "--/--/---",yui);
                        r="REGISTRATION ADDED";
                    }
                } else
                {
                    
                            r="Already exists !!  you are entering a fake REGISTRATION NUMBER ";
                }
          

                return r;

    }
    /*private void enter()
    {
        try {

            CsvReader products = new CsvReader("users.csv");

            products.readHeaders();

            while (products.readRecord())
            {
                String R_no= products.get("REGESTRATION NUMBER");
                String FName = products.get("FIRST NAME");
                String LName = products.get("LASTNAME");
                String Branch = products.get("BRANCH");
                String b1 = products.get("BOOK1");
                String b1_ISD = products.get("BOOK1 ISSUE DATE");
                String b1_RTD = products.get("BOOK1 RETURN DATE");
                String b2 = products.get("BOOK2");
                String b2_ISD= products.get("BOOK2 ISSUE DATE");
                String b2_RTD = products.get("BOOK2 RETURN DATE");

                // perform program logic here
                insert(R_no,FName,LName,Branch,b1,b1_ISD,b1_RTD,b2,b2_ISD,b2_RTD);
                //System.out.println(R_no + ":" +b1 + "  " + b2);
            }

            products.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }*/
    private void enter()
    {
          Connection s =null;
        Statement s1=null;
        ResultSet s2=null;
        String q ="Select * from TATHAGAT.STD";
        try{
            s=DriverManager.getConnection("jdbc:derby://localhost:1527/Student", "tathagat", "tathagat");
            s1=s.createStatement();
            s2=s1.executeQuery(q);
            while(s2.next())
            {
            
             String reg1 = s2.getString(1);
             String reg2 = s2.getString(2);
             String reg3 = s2.getString(3);
             String reg4 = s2.getString(4);
                String reg5 = s2.getString(5);
                    String reg6 = s2.getString(6);
                        String reg7 = s2.getString(7);
                            String reg8 = s2.getString(8); 
                            String reg9 = s2.getString(9);
                                String reg10 = s2.getString(10);
                                String reg11=s2.getString(11);
                                insert(reg1,reg2,reg3,reg4,reg5,reg6,reg7,reg8,reg9,reg10,reg11);
                                
                            
               // System.out.println(reg1+"  "+reg2+"  "+reg3+"  "+reg4+"  "+reg5+"  "+reg6+"  "+reg7+"  "+reg8+"  "+reg9+"  "+reg10);
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
    
    
    
    
    
    
    
   private Connection connect() {
        // SQLite connection string
        String url = "jdbc:derby://localhost:1527/Student";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, "tathagat", "tathagat");
          //  System.out.println(e.getMessage());
            
        }
        catch (SQLException e) {
 e.printStackTrace();


    }
       return conn; 
   }
   
    public void insert12(String s1,String s2,String s3,String s4,String s5,String s6,String s7,String s8,String s9,String s10,String s11) {
        String sql = "INSERT INTO STD(REGISTRATION_NUMBER,FIRST_NAME,LAST_NAME,BRANCH,BOOK1,BOOK1_ISSUE,BOOK1_RETURN,BOOK2,BOOK2_ISSUE,BOOK2_RETURN,NUMER) VALUES(?,?,?,?,?,?,?,?,?,?,?)";

        try (Connection conn = this.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, s1);
             pstmt.setString(2, s2);
             pstmt.setString(3, s3);
             pstmt.setString(4, s4);
             pstmt.setString(5, s5);
             pstmt.setString(6, s6);
             pstmt.setString(7, s7);
             pstmt.setString(8, s8);
             pstmt.setString(9, s9);
             pstmt.setString(10, s10);
             pstmt.setString(11, s11);
            
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    public void update(String r , String r1 , String r2,String r3,String r4,String r5,String r6) {
        /*char[] r1c = r1.toCharArray();
        char[] r2c = r2.toCharArray();
        char[] r3c = r3.toCharArray();

        char[] r4c = r4.toCharArray();
        char[] r5c = r5.toCharArray();
        char[] r6c = r6.toCharArray();*/


        String sfilename = "users.csv";
        File fileToBeModified = new File(sfilename);

        String oldContent = "";

        BufferedReader reader = null;

        FileWriter writer = null;

        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));

            //Reading all the lines of input text file into oldContent

            String line = reader.readLine();

            String s ="";
            File f=new File("users.csv");
            f.delete();


            /**/
            int iot=0;
            PrintWriter pw = new PrintWriter(new File("users.csv"));
            StringBuilder sb = new StringBuilder();

            while (line != null)
            {
                //oldContent = oldContent + line + System.lineSeparator();


                char a[]=line.toCharArray();
                int c=0,d=0;
                char []ar=oldContent.toCharArray();


                String[]  atr = line.split(",");
                    /*for (int j = 0; j < atr.length; j++) {
                        System.out.println(atr[j]);
                    }*/


                    for (int i = 0; i < line.length(); i++) {
                        if (i >= 0 && i <= 8) {
                            s = s + a[i];
                        }
                    }

                    if (s.equalsIgnoreCase(r)) {

                        atr[4]=r1;
                        atr[5]=r2;
                        atr[6]=r3;
                        atr[7]=r4;
                        atr[8]=r5;
                        atr[9]=r6;
                    }

                for(int write=0;write<atr.length;write++)
                {

                    sb.append(atr[write]);
                    sb.append(',');


                }
                sb.append('\n');





                s="";
                iot=1;
                line = reader.readLine();

            }
            pw.write(sb.toString());
            pw.close();
            System.out.println("done!");


            //System.out.println(s);
            //Replacing oldString with newString in the oldContent

            /*String newContent = oldContent.replaceAll(oldString, newString);

            //Rewriting the input text file with newContent

            writer = new FileWriter(fileToBeModified);

            writer.write(newContent);*/
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

 public void update1(String r )
 {
     
      try  {
 
            // prepare data for update
            Connection  con = DriverManager.
                    getConnection("jdbc:derby://localhost:1527/Student"
                        ,"tathagat","tathagat");
         
           Statement st;
           st=con.createStatement();
 
           
           int rr=st.executeUpdate("DELETE FROM STD WHERE NUMER in("+r+")");
           
           System.out.println(rr);
           
           
           
 
 
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
     
    }
 
    public   void  insert1(String s1,String s2,String s3,String s4,String s5,String s6,String s7,String s8,String s9,String s10)
    {
        String outputFile = "users.csv";

        // before we open the file check to see if it already exists
        boolean alreadyExists = new File(outputFile).exists();

        try {
            // use FileWriter constructor that specifies open for appending
            CsvWriter csvOutput = new CsvWriter(new FileWriter(outputFile, true), ',');

            // if the file didn't already exist then we need to write out the header line
            if (!alreadyExists)
            {
                csvOutput.write("REGESTRATION NUMBER");
                csvOutput.write("FIRST NAME");
                csvOutput.write("LASTNAME");
                csvOutput.write("BRANCH");
                csvOutput.write("BOOK1");
                csvOutput.write("BOOK1 ISSUE DATE");
                csvOutput.write("BOOK1 RETURN DATE");
                csvOutput.write("BOOK2");
                csvOutput.write("BOOK2 ISSUE DATE");
                csvOutput.write("BOOK2 RETURN DATE");
                csvOutput.endRecord();
            }
            // else assume that the file already has the correct header line

            // write out a few records
            csvOutput.write(s1);
            csvOutput.write(s2);
            csvOutput.write(s3);
            csvOutput.write(s4);
            csvOutput.write(s5);
            csvOutput.write(s6);
            csvOutput.write(s7);
            csvOutput.write(s8);
            csvOutput.write(s9);
            csvOutput.write(s10);
            csvOutput.endRecord();


            csvOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
