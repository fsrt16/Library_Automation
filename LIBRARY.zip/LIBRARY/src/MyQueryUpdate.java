
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
 
public class MyQueryUpdate {
 private  Connection connect() {
        // SQLite connection string
        String url = "jdbc:derby://localhost:1527/Student";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, "tathagat", "tathagat");
          //  System.out.println(e.getMessage());
            
        }
        catch (SQLException e) {
 e.printStackTrace();


    }
       return conn; 
   }
   
    public  void insert12(String s1,String s2,String s3,String s4,String s5,String s6,String s7,String s8,String s9,String s10,String s11) {
        
    }
    public static void main(String[] args) {

            String s[]={"17BCE7100","TATeheshHAGAT","BANERehhtrJEE","CSE","--","--","--","--","--","--","1"};

 
        
        try  {
 
            // prepare data for update
            Connection  con = DriverManager.
                    getConnection("jdbc:derby://localhost:1527/Student"
                        ,"tathagat","tathagat");
         
           Statement st;
           st=con.createStatement();
 
           String y="1";
           int rr=st.executeUpdate("DELETE FROM STD WHERE NUMER in("+y+")");
           
           System.out.println(rr);
           
     
       
       
           
 
 
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            
}
}


