
import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


 public class Book_Details {


         String []a=new String[30];
     String s;
     String t[];
    /* Class containing left and right child of current node and key value*/
    class Node {
        String k1;
        int key;
        String Book_name;
        String Author;
        String Branch;

        Node left, right;

        public Node(int item, String f, String l, String b, String k) {
            this.key = (item);
            this.Book_name = f;
            this.Author = l;
            this.Branch = b;
            this.k1 = k;
            //System.out.println(this.key + " "+this.Book_name+" "+this.Author+" "+this.Branch);
            left = right = null;
        }
    }

    // Root of BST
    Node root;

    // Constructor
    Book_Details() {
        root = null;
       { 
        initiate();
       }
        

    }


    // This method mainly calls insertRec()
    void insert(String key, String f, String l, String b) {

    
        
        int key1 = decode(key);
        root = insertRec(root, key1, f, l, b, key);
        
        }


    /* A recursive function to insert a new key in BST */
    Node insertRec(Node root, int key, String f, String l, String b, String k) {

        /* If the tree is empty, return a new node */
        if (root == null) {
            root = new Node(key, f, l, b, k);
            return root;
        }

        /* Otrwise, recur down the tree */
        if (key < root.key)
            root.left = insertRec(root.left, key, f, l, b, k);
        else if (key > root.key)
            root.right = insertRec(root.right, key, f, l, b, k);

        /* return the (unchanged) node pointer */
        return root;
    }
    

    // This method mainly calls InorderRec()
    void inorder() {
        inorderRec(root);
    }

    // A utility function to do inorder traversal of BST
    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.k1 + "  " + root.Book_name + "  " + root.Author + "  " + root.Branch);
            inorderRec(root.right);
        }
    }
   

    public int decode(String a) {
        a = a.toUpperCase();
        char a1[] = a.toCharArray();
        int s = 0;
        for (int i = 0; i < a.length(); i++) {
            s = s + i * (int) a1[i];
        }
        return s;
    }

    public Node findNodeInBST(Node node, int value) {
        if (null == node) {
            return null;
        }
        //Condition 1. we found the value
        if (node.key == value) {
            return node;
        }
        //Condition 2.
        //Value is less than node value. so go left sub tree
        else if (value < node.key)
            return findNodeInBST(node.left, value);
            //Condition 3.
            //Value is greater than node value. so go right sub tree
        else
            return findNodeInBST(node.right, value);
    }

    public String searc_IS(String p)
    {
        sn(root,p);
        return s;
    }
    public void sn(Node root,String p)
    {
        if(root!=null)
        {
            sn(root.left,p);
            if(root.k1.equals(p))
            {
                 s=root.Book_name+"   "+root.Author+"   "+root.Branch;
                
            }
            sn(root.right,p);
        }
    }
    public String[] search_name(String s) {
        srch(root, s,0);
       String a1[]= prn();
       return a;
    }
    public String[] prn()
    {

        int c=0;

        for(int i=0;i<a.length;i++)
        {
            if(a[i]!=null)
            {


                c++;
            }
        }
       return a;
    }

    public void srch(Node root, String s,int i) {
        if (root != null) {
            srch(root.left, s,i);
            if (root.Book_name.contains(s)) {
               // System.out.print("  "+root.k1 + "  " + root.Book_name + "  " + root.Author + "  " + root.Branch);

                a[i]="  "+root.k1 + "   " + root.Book_name + "   " + root.Author + "   " + root.Branch;
                i=i+1;
            }
            srch(root.right, s,i);
        }
    }

    public String[] search_auth(String s) {
        srch1(root, s,0);
         String a1[]=prn();
        
        return a;
        
    }

    public void srch1(Node root, String s,int i) {

        if (root != null) {
            srch1(root.left, s,i);
            if (root.Author.contains(s)) {

             //System.out.println(root.Author);

                a[i]=root.k1 + "   " + root.Book_name + "   " + root.Author + "   " + root.Branch;
                i=i+1;
            }
            srch1(root.right, s,i);

        }
    }

   



    public  void initiate()
    {
        enter();
       }
   /* public  void jlt(){

        insert1("ISIB6924AP","Basics of Programming ","MK Mathew ","CSE");
        insert1("ISIB7824AP","Basics of Programming WITH C++ ","MK SHAW ","CSE");
        insert1("ISIB3524AP","Basics of Programming WITH PYTHON ","DR. RENIN TERAN ","CSE");
        insert1("ISIB8694AP","Basics of Programming WITH JAVA ","STEVEN SMITH ","CSE");
        insert1("ISIB7924AP","Basics of DATA SRTUCTURES ","ROHIT SHARMA ","CSE");
        insert1("ISIB6624AP","Basics of OOPS ","VIRAT KOHLI ","CSE");
        insert1("ISIB6724AP","ADVANCED Programming ","MS DHONI","CSE");
        insert1("ISIB6824AP","ADVANCED Programming WITH C++","SACHIN TENDULKAR","CSE");
        insert1("ISIB7124AP","ADVANCED Programming WITH PYTHON","JAQUES KALLIS","CSE");
        insert1("ISIB7224AP","ADVANCED DATA STRUCTURES WITH PYTHON","GREME SMITH","CSE");
        insert1("ISIB7324AP","GRAPHICAL USER PROGRAMMING ","KUMAR SANGAKARA ","CSE");
        insert1("ISIB7524AP","BASICS OF ELECTRICAL ENGENEERIING ","MAHELLA JAYWARDHANE ","ECE");
        insert1("ISIB8924AP","FOUNDATION OF DATA ANALYTICS ","KRISHNEMACHARI SRIKANTH ","CSE");
        insert1("ISIM8724AP","MACHINE LEARNING AND DEEP LEARNING WITH R ","VVS LAXMAN ","CSE");
        insert1("ISIM8824AP","DATA BASE MANAGEMENT SYSTEM ","DENNIS LILI ","CSE");
        insert1("ISIM8424AP","FOUNDATION OF ECE","NARUTO UZUMAKI","ECE");
        insert1("ISIB5224AP","CONNECTION AND SYSTEMS","NINE TAILED FOX ","ECE");
        insert1("ISIB5324AP","EMBEDED SYSTEM AND CONTROLS ","SHEKUCHI SUTZOBA ","ECE");
        insert1("ISIB5424AP","VHDL PROGRAMMING ","MK Math ","ECE");
        insert1("ISIM5524AP","EASE OF CONNECTION","MK Math ","ECE");
        insert1("ISIM5624AP","MULTISIM TRASPAREMENT ","MK Math ","ECE");
        insert1("ISIM5724AP","FLUID MECHANICS ","MK Mathe ","MECH");
        insert1("ISIM5824AP","MECHANICS-I ","M Mathew ","MECH");
        insert1("ISIM9724AP","MECHANICS-II ","M thew ","MECH");
        insert1("ISIM9924AP","ROTATIONAL DYNAMICS-I ","MARAN","MECH");
        insert1("ISIB9524AP","SOFTWARE DEVLOPMENT SYSTEM ","MOS B ","MIS");
        insert1("ISIM9224AP","TOOLS OF SOFTWARE DEVLOPMENTS ","MK C ","MIS");
        insert1("ISIM9624AP","Basics of SOFTWARE ENGINEERING ","MK B ","MIS");
        insert1("ISIM4224AP","SCIENCE OF SOFTWARES","MK L ","MIS");
        insert1("ISIM2124AP","TOOL END MINNING ","MK JIO ","MTECH");
    }
*/
   private Connection connect() {
        // SQLite connection string
        String url = "jdbc:derby://localhost:1527/Student";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, "tathagat", "tathagat");
          //  System.out.println(e.getMessage());
            
        }
        catch (SQLException e) {
 e.printStackTrace();


    }
       return conn; 
   }
   
    public void insert1(String s1,String s2,String s3,String s4) {
        String sql = "INSERT INTO BOOK(ISIBN,BOOK_NAME,AUTHOR,BRANCH) VALUES(?,?,?,?)";

        try (Connection conn = this.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, s1);
             pstmt.setString(2, s2);
             pstmt.setString(3, s3);
             pstmt.setString(4, s4);
             
          
            
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
        private void enter()
    {
          Connection s =null;
        Statement s1=null;
        ResultSet s2=null;
        String q ="Select * from TATHAGAT.BOOK";
        try{
            s=DriverManager.getConnection("jdbc:derby://localhost:1527/Student", "tathagat", "tathagat");
            s1=s.createStatement();
            s2=s1.executeQuery(q);
            while(s2.next())
            {
            
             String reg1 = s2.getString(1);
             String reg2 = s2.getString(2);
             String reg3 = s2.getString(3);
             String reg4 = s2.getString(4);
                                insert(reg1,reg2,reg3,reg4);
                                
             
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

        public String[] enter1()
    {
          Connection s =null;
        Statement s1=null;
        ResultSet s2=null;
        String q ="Select * from TATHAGAT.BOOK";
        try{
            s=DriverManager.getConnection("jdbc:derby://localhost:1527/Student", "tathagat", "tathagat");
            s1=s.createStatement();
            s2=s1.executeQuery(q);
            int i=0;
            while(s2.next())
            {
            
             String reg1 = s2.getString(1);
             String reg2 = s2.getString(2);
             String reg3 = s2.getString(3);
             String reg4 = s2.getString(4);
                                insert(reg1,reg2,reg3,reg4);
                                
                            
             a[i]=  reg1+","+reg2+","+reg3+","+reg4;
              i++;  
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return a;

    }
    public String BOOK_INPUT (String a1 , String b1 , String c1 , String d1)
    {
       
        
            a1=a1.toUpperCase();
            b1=b1.toUpperCase();
            c1=c1.toUpperCase();
            d1=d1.toUpperCase();
            Node n=findNodeInBST(root,decode(a1));
            String r;
            if(n==null)
            {
                insert1(a1,b1,c1,d1);
                insert(a1,b1,c1,d1);
                inorder();
                r = "done";
                
            }
            else
            {
                r="t";
                
            }
            return r;
        }
    
    public int CHECK_FOR_REGISTRATION_NUMBER(String reg_no)
    {
        

        Node a = root;

        while(a!=null)
        {
            if(a.key == decode(reg_no))
                return 0;
            else if(a.key < decode(reg_no))
            {

                a=a.right;
            }
            else
            {

                a=a.left;
            }

        }
        return 1;
    }


}
